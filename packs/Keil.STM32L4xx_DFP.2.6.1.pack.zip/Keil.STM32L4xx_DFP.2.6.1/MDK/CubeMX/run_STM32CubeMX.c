/******************************************************************************
 * File Name   : runSTM32CubeMX.c
 * Date        : 20/07/2021 12:00:00
 * Description : This file provokes a build error. It is only included in
 *               the project if STM32CubeMX has not yet generated a gpdsc file
 *               overriding this component with the generated files from 
 ******************************************************************************/

#error "Run STM32CubeMX (open Run-Time Environment dialog, expand Device and STM32CubeMX Framework components and press the play button). Within STM32CubeMX configure and run code generation."
