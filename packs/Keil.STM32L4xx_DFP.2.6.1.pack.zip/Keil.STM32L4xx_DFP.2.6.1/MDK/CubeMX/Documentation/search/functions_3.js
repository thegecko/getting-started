var searchData=
[
  ['hal_5fspi_5ferrorcallback',['HAL_SPI_ErrorCallback',['../_s_p_i___s_t_m32_l4xx_8c.html#a3db7835e7e7ac335887f62fedf156926',1,'SPI_STM32L4xx.c']]],
  ['hal_5fspi_5frxcpltcallback',['HAL_SPI_RxCpltCallback',['../_s_p_i___s_t_m32_l4xx_8c.html#a3df7021fe24cf874f8b1eec5bd5f4cb3',1,'SPI_STM32L4xx.c']]],
  ['hal_5fspi_5ftxcpltcallback',['HAL_SPI_TxCpltCallback',['../_s_p_i___s_t_m32_l4xx_8c.html#a0a99ab4f6aa6ee7dc2abca5483910dde',1,'SPI_STM32L4xx.c']]],
  ['hal_5fspi_5ftxrxcpltcallback',['HAL_SPI_TxRxCpltCallback',['../_s_p_i___s_t_m32_l4xx_8c.html#a04e63f382f172164c8e7cae4ff5d883c',1,'SPI_STM32L4xx.c']]]
];
