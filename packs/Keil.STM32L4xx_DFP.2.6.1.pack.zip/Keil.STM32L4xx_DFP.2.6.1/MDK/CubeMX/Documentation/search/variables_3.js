var searchData=
[
  ['otg_5ffs_5frole',['otg_fs_role',['../_o_t_g___s_t_m32_l4xx_8c.html#a26ab77ee0820c394d9701a10060dd994',1,'OTG_STM32L4xx.c']]]
];
