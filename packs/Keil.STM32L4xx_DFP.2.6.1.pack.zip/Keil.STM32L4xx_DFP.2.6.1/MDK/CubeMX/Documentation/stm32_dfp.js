var stm32_dfp =
[
    [ "CMSIS-Driver MCI Setup", "stm32l4_mci.html", null ],
    [ "CMSIS-Driver SPI Setup", "stm32l4_spi.html", null ],
    [ "CMSIS-Driver USART Setup in IRDA mode", "stm32l4_usart_irda.html", null ],
    [ "CMSIS-Driver USART Setup", "stm32l4_usart.html", null ],
    [ "CMSIS-Driver UART Setup", "stm32l4_uart.html", null ],
    [ "CMSIS-Driver USART Setup in SmartCard mode", "stm32l4_usart_smart.html", null ],
    [ "CMSIS-Driver USBD_OTG Setup", "stm32l4_usbd.html", null ],
    [ "CMSIS-Driver USBH_OTG Setup", "stm32l4_usbh.html", null ]
];